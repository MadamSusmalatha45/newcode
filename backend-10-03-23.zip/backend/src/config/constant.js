const domainName = `${req.protocol}://${req.headers.host}`;

module.exports = {domainName}
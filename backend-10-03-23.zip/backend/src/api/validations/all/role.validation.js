const Joi = require('joi');

module.exports = {

  // GET /v1/Statuss
  listRoles: {
    query: {
    },
  },

};

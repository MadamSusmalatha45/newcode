import { Box, Typography } from "@mui/material";
import { grey } from "@mui/material/colors";
import React from "react";

// eslint-disable-next-line react/prop-types
function VerticleSpace({ height }) {
  return (
    <Box display="flex" flexDirection="column" style={{height : height}}>
      
    </Box>
  );
}

export default VerticleSpace;
